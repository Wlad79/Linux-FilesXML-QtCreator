#!/bin/bash
#Ausführbar machen und aufrufen
#chmod +x /pfad/zu/mein_skript.sh % ./mein_skript.sh  oder /bin/bash ./mein_skript.sh 
#bash mein_skript.sh
echo "auch # kein Kommentar innerhalb" # , wohl aber außerhalb : 
#https://askubuntu.com/questions/219629/pkg-config-error-no-such-file-or-directory
gcc main.cpp -o gtkhello `pkg-config gtk+-3.0 --cflags --libs`
