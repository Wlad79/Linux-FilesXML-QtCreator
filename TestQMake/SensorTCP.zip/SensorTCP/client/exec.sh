#!/bin/bash
#Ausführbar machen und aufrufen
#chmod +x /pfad/zu/mein_skript.sh % ./mein_skript.sh  oder /bin/bash ./mein_skript.sh 
#bash mein_skript.sh
echo "start after compiling!"
./client localhost 2525

