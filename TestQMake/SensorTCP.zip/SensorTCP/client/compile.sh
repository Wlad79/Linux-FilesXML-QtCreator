#!/bin/bash
#Ausführbar machen und aufrufen
#chmod +x /pfad/zu/mein_skript.sh % ./mein_skript.sh  oder /bin/bash ./mein_skript.sh 
#bash mein_skript.sh
echo "run after install gcc on linux"
gcc client.c -o client
