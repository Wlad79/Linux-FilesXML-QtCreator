#include "data_manager.h"
#include "sensor_sleeped.h"
#include <vector>
#include <unistd.h>
#define num_of_parallel_clients 5

Data_Manager::Data_Manager()
{
    std::vector<Sensor_Sleeped*> clients;
    while(true)
    {

        if(clients.empty())
        {
            for(int i= 0; i<num_of_parallel_clients;i++)
            {
                Sensor_Sleeped *link = new Sensor_Sleeped();
                clients.emplace_back(link);
            }
        }
        std::vector<Sensor_Sleeped*>::iterator current = clients.begin();
        for(auto* element: clients)
        {
            if(element->isClosed())
            {
                delete element;
                element=NULL;
                Sensor_Sleeped *link = new Sensor_Sleeped();
                clients.emplace_back(link);
            }
            else
            {
                *current++ = element;
            }
        }
        clients.erase(current, clients.end());
        //sleep(250);
    }


    //Sensor_Sleeped *link2 = new Sensor_Sleeped();
    //delete link2;
}
