#ifndef SENSOR_SLEEPED_H
#define SENSOR_SLEEPED_H
#include "servertcp.h"

class Sensor_Sleeped// : public ServerTCP
{
public:
    Sensor_Sleeped();
    ~Sensor_Sleeped(){}
    bool isClosed();
    void iClientsBinding();
    void StateMachineProtokoll();

private:
    ServerTCP *server;
    enum States{
        binding,
        reading,
        closing
    };
    States communication_state;


};

#endif // SENSOR_SLEEPED_H
