#ifndef SERVERTCP_H
#define SERVERTCP_H

//#include <thread>

class ServerTCP// : public thread
{
public:
    ServerTCP();
    ~ServerTCP();
    void binding();
    int getAmountOfConnections();
    void reading(int connection);
    void writing();
    //virtual void StateMachineProtokoll();
    enum States{
        created,
        running,
        closed
    };
    bool isAborted();

private:

    int sockfd, newsockfd, portno;
    char buffer[256];
    int n;

    States state;

    void error(const char *msg);

};

#endif // SERVERTCP_H
