#include <QCoreApplication>
#include "data_manager.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    Data_Manager app;
    while(true)
    {

    }
    return a.exec();
}
