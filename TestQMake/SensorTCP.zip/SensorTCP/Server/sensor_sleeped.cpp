#include "sensor_sleeped.h"
#include <thread>

#include <vector>

//std::vector<std::thread> reading_threads;

Sensor_Sleeped::Sensor_Sleeped()
{
    server = new ServerTCP();
    communication_state = binding;
    StateMachineProtokoll();
}

void iClientsBinding()
{
    //binding();
}

void Sensor_Sleeped::StateMachineProtokoll()
{
    std::thread first (server);
    first.join();
    while(true)
    {
        switch(communication_state)
        {
            case binding:
                communication_state = reading;
                break;
            case reading:
                server->reading(0);
                if(server->isAborted())
                    communication_state = closing;
                break;
            case closing:
                //delete this;
                //return;
                break;
        }
    }
}

bool Sensor_Sleeped::isClosed()
{
    if(communication_state == closing)
        return true;
    else {
        return false;
    }
}
