#ifndef DATA_MANAGER_H
#define DATA_MANAGER_H


class Data_Manager
{
public:
    Data_Manager();
};

#endif // DATA_MANAGER_H