//https://www.cs.usfca.edu/~galles/cs420/lecture/LuaLectures/LuaAndC.html
#include <iostream>
#include <lua.hpp>

int halloFunc(lua_State* L)
{
    lua_getglobal(L, "hallo");

    // Push the argument (the number 3) on the stack
    lua_pushnumber(L, 3);
    // Push the argument (the number 5) on the stack
    lua_pushnumber(L, 5);

    // Call the function with 2 arguments, returning 1 result
    lua_call(L, 2, 1);

    // Get the result
    int res = (int)lua_tointeger(L, -1);

    // The one result that was returned needs to be popped off.  If the 3rd
    //  parameter to lua_call was larger than 1, we would need to pop off more
    //  elements from the lua stack.
    lua_pop(L, 1);

    return res;
}

int luaAdd(lua_State* L, int a, int b)
{

    // Push the add function on the top of the lua stack
    lua_getglobal(L, "add");

    // Push the first argument on the top of the lua stack
    lua_pushnumber(L, a);

    // Push the second argument on the top of the lua stack
    lua_pushnumber(L, b);

    // Call the function with 2 arguments, returning 1 result
    lua_call(L, 2, 1);

    // Get the result
    int sum = (int)lua_tointeger(L, -1);

    // The one result that was returned needs to be popped off.  If the 3rd
    //  parameter to lua_call was larger than 1, we would need to pop off more
    //  elements from the lua stack.
    lua_pop(L, 1);

    return sum;
}

int main(int argc, char *argv[])
{
    lua_State* L;

        // initialize Lua interpreter
        L = luaL_newstate();

        // load Lua base libraries (print / math / etc)
        luaL_openlibs(L);

        ////////////////////////////////////////////
        // We can use Lua here !
        //   Need access to the LuaState * variable L
        /////////////////////////////////////////////
        luaL_dofile(L, "test.lua");
        // Push the fib function on the top of the lua stack
            lua_getglobal(L, "fib");

            // Push the argument (the number 13) on the stack
            lua_pushnumber(L, 13);

            // call the function with 1 argument, returning a single result.  Note that the function actually
            // returns 2 results -- we just want one of them.  The second result will *not* be pushed on the
            // lua stack, so we don't need to clean up after it
            lua_call(L, 1, 3);

            // Get the result from the lua stack
            int result1 = (int)lua_tointeger(L, lua_gettop( L ));

            // Clean up.  If we don't do this last step, we'll leak stack memory.
            lua_pop(L, 1);
            // Get the result from the lua stack
            int result2 = (int)lua_tointeger(L, lua_gettop( L ));

            // Clean up.  If we don't do this last step, we'll leak stack memory.
            lua_pop(L, 1);
            // Get the result from the lua stack
            int result3 = (int)lua_tointeger(L, lua_gettop( L ));

            // Clean up.  If we don't do this last step, we'll leak stack memory.
            lua_pop(L, 1);

        // Cleanup:  Deallocate all space assocatated with the lua state */


        // Hack to prevent program from ending immediately
        printf( "Press enter to exit...%d\n", luaAdd(L, 3,5) );
        printf( "Press enter to exit...%d    , %d,    %d", result1, result2, result3 );
        printf( "Press enter to exit...%d", halloFunc(L) );
        lua_close(L);
        getchar();

        return 0;
}
