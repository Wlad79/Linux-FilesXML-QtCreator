#!/bin/bash
#Ausführbar machen und aufrufen
#chmod +x /pfad/zu/mein_skript.sh % ./mein_skript.sh  oder /bin/bash ./mein_skript.sh 
#bash mein_skript.sh
echo "auch # kein Kommentar innerhalb" # , wohl aber außerhalb
cc -o test main.cpp -I/usr/local/include/lua -L/usr/local/lib -llua -lm -ldl
