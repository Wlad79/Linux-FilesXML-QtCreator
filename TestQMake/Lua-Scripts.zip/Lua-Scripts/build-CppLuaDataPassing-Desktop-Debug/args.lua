io.write( "[lua] These args were passed into the script from C\n" );
length = arg.n
for i=1,length do
   print(i,arg[i])
end

io.write("[lua] Script returning data back to C\n")

local temp = {}
temp[1]=9
temp[2]=8
temp[3]=7
temp[4]=6
temp[5]=5
temp[6]=4
temp[7] = 3

local temp2 = {}
temp2[1]=9
temp2[2]=8
temp2[3]=7

return temp,temp2,9,1
