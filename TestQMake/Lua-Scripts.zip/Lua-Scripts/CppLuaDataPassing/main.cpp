//http://lua-users.org/wiki/CppLuaDataPassing
//https://www.lua.org/manual/5.1/manual.html#2.8
//https://www.lua.org/manual/2.4/node16.html
//https://stackoverflow.com/questions/28723535/how-can-fix-it
//https://stackoverflow.com/questions/8552560/embedding-lua-in-c
//http://www.troubleshooters.com/codecorn/lua/lua_c_calls_lua.htm
//http://intern.fh-wedel.de/~si/seminare/ws09/Ausarbeitung/09.lua/lua5.htm
//
//extern "C"
//{
//   #include <lua.h>
//   #include <lauxlib.h>
//   #include <lualib.h>
//}
#include <iostream>
#include <lua.hpp>

#define lua_open()	luaL_newstate()

//https://stackoverflow.com/questions/28723535/how-can-fix-it
// a list of libs to expose for use in scripts
static const luaL_Reg lualibs[] =
{
  {"base", luaopen_base},
  {"table", luaopen_table},
  {"io", luaopen_io},
  {"string", luaopen_string},
  {"math", luaopen_math},
  {"debug", luaopen_debug},
  //{"loadlib", luaopen_loadlib},
    {"coroutine", luaopen_coroutine},
    {"os", luaopen_os},
    {"package", luaopen_package},
  /* add your libraries here */
  {NULL, NULL}
};

// load the list of libs
static void openstdlibs( lua_State *l )
{
  const luaL_Reg *lib = lualibs;
  for (; lib->func; lib++)
  {
    lib->func(l);  /* open library */
    lua_settop(l, 0);  /* discard any results */
  }
}

int main()
{
   int status;
   lua_State* state = lua_open();
   luaL_openlibs(state);


   openstdlibs( state );
   status = luaL_loadfile( state, "args.lua" );

   std::cout << "[C++] Passing 'arg' array to script" << std::endl;

   // start array structure
   lua_newtable( state );

   // set first element "1" to value 45
   lua_pushnumber( state, 1 );
   lua_pushnumber( state, 45 );
   lua_rawset( state, -3 );

   // set second element "2" to value 99
   lua_pushnumber( state, 2 );
   lua_pushnumber( state, 99 );
   lua_rawset( state, -3 );

   // set second element "3" to value 299
   lua_pushnumber( state, 3 );
   lua_pushnumber( state, 299 );
   lua_rawset( state, -3 );

   // set second element "4" to value 199
   lua_pushnumber( state, 4 );
   lua_pushnumber( state, 199 );
   lua_rawset( state, -3 );

   // set the number of elements (index to the last array element)
   lua_pushliteral( state, "n" );
   lua_pushnumber( state, 5 );
   lua_rawset( state, -3 );

   // set the name of the array that the script will access
   lua_setglobal( state, "arg" );


   std::cout << "[C++] Running script" << std::endl;

   int result = 0;
   if (status == 0)
      result = lua_pcall( state, 0, LUA_MULTRET, 0 );
   else
      std::cout << "bad" << std::endl;

   if (result != 0)
      std::cerr << "[C++] script failed" << std::endl;

   std::cout << "[C++] These values were returned from the script" << std::endl;

   while (lua_gettop( state ))
   {
      switch (lua_type( state, lua_gettop( state ) ))
      {
         case LUA_TNUMBER: std::cout << "script returned " << lua_tonumber( state, lua_gettop( state ) ) << std::endl; break;
         case LUA_TTABLE:
          lua_getglobal(state,"temp2");
          while (lua_next(state, 2) != 0)
          {
              std::cout << "script returned a table: " << lua_rawlen(state, 2) << "-len, Content:" << lua_tonumber( state, lua_gettop( state ) ) << std::endl;
              lua_pop(state, 1);
          }
          break;
         case LUA_TSTRING:
          std::cout << "script returned " << lua_tostring( state, lua_gettop( state ) ) << std::endl;
          break;
         case LUA_TBOOLEAN:std::cout << "script returned " << lua_toboolean( state, lua_gettop( state ) ) << std::endl; break;
         default: std::cout << "script returned unknown param" << std::endl; break;
      }
      lua_pop( state, 1 );
   }
   lua_close( state );
   return 0;
}
