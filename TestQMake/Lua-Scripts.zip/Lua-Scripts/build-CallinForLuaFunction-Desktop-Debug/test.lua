hallo = function(x,y)
local t = x*y
io.write("\nthe script has received:\n");
print("x=", x, "y=",y, "x*y=")
	return t
end

--print(hallo(2,3))

function fib(n)
   if n == 1 or n == 2 then
      return 1,1
   end
   prev, prevPrev = fib(n-1)
   return prev+prevPrev, prev, 100
end

add = function(a,b)
io.write("\nthe script has received:\n");
print("x=", a, "y=",b, "x+y=")
    return a + b
end

--print(fib(13))
--print((fib(10)))
