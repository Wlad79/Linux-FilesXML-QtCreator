// XmlParser.cpp : Defines the entry point for the console application.
//https://www.codeguru.com/cpp/i-n/internet/xml/article.php/c3451/STLbased-nonvalidating-XML-Parser.htm

#include "StdAfx.h"

#define DebugDisplay

#include "XmlStream.h"

//#include <ncurses.h>//https://stackoverflow.com/questions/29335758/using-kbhit-and-getch-on-linux
#include <sys/ioctl.h>//https://stackoverflow.com/questions/29335758/using-kbhit-and-getch-on-linux
#include <termios.h>//https://stackoverflow.com/questions/29335758/using-kbhit-and-getch-on-linux
//#include <conio.h>//https://www.c-plusplus.net/forum/topic/39320/getch-getche-kbhit-getchar
#include <string>
#include <iostream>
using namespace std;

#if defined(_DEBUG)
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


void initContact ( stringstream & strm, LPCTSTR cname, long id,
                   bool hasAttributes = false,
                   bool showToDo = false )
{
    if ( hasAttributes )
        strm << "<Contact language=english hasEmail=false>" << endl;
    else
        strm << "<Contact>" << endl;
    strm << "<name>" << cname << "</name>" << endl;
    strm << "<id>" << id << "</id>" << endl;

    if ( showToDo )
    {
        strm << "<ToDo>" << endl;
        strm << "<Item></Item>" << endl;
        strm << "<Item/>" << endl;
        strm << "<Item>Call</Item>" << endl;
        strm << "<Item>Say Hello</Item>" << endl;
        strm << "<Item>Take Notes</Item>" << endl;
        strm << "<Item>HangUp</Item>" << endl;
        strm << "</ToDo>" << endl;

    }

    strm << "</Contact>" << endl;
}

/*
 *
 * https://stackoverflow.com/questions/29335758/using-kbhit-and-getch-on-linux
 *
 */
bool kbhit()
{
    termios term;
    tcgetattr(0, &term);

    termios term2 = term;
    term2.c_lflag &= ~ICANON;
    tcsetattr(0, TCSANOW, &term2);

    int byteswaiting;
    ioctl(0, FIONREAD, &byteswaiting);

    tcsetattr(0, TCSANOW, &term);

    return byteswaiting > 0;
}

int main(int argc, char* argv[])
{
    // setup mem check
    #if defined(_DEBUG)
    _CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
    #endif


    // notice that no xml document declaration is included nor
    // is a schema included. if those exist in your buffer dont
    // send them to the parser. later will add the code to
    // step through these. so this is a nonvalidating parser.
    // there is one bug in the parser. when an empty node
    // is encountered it will be reported as an element
    // this will be fixed later. if you have any suggestions
    // or improvements let me know.

    // set buffer
    long id = 100;

    stringstream strm;
    strm << "<Contacts>" << endl;

    strm << "<Contact/>" << endl;

    initContact( strm, "Waldemar Friesen", 100 );
    initContact( strm, "John Doe", 200 );
    initContact( strm, "Mary Jane", 300, true, true );
    initContact( strm, "Wanda Ward", 400 );

    strm << "</Contacts>" << endl;


    string str = strm.str();

    // parse document
    XmlStream xml;
    xml.parse( (char *) str.c_str(), str.size() - 1 );

    while ( !kbhit() );
    //while ( true );

    return 0;
}

